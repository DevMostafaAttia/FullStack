﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Client.Model
{
    public class Client
    {
        public int ClientId { get; set; }
        public string ClientName { get; set; }
        public string ClientEmail { get; set; }
        public string Mobile { get; set; }
        public string Address { get; set; }
        public string WebSite { get; set; }

    }
}
