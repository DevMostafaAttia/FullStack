import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule } from '@angular/common/http';
import {FormsModule} from '@angular/forms'

import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations'
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ConfirmationPopoverModule } from 'angular-confirmation-popover';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatToolbarModule} from '@angular/material/toolbar';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ClientsComponentComponent } from './clients-component/clients-component.component';
import { ClientsListComponentComponent } from './clients-component/clients-list-component/clients-list-component.component';
import { ClientComponentComponent } from './clients-component/client-component/client-component.component';
import { ClientService } from './clients-component/client.service'
 
import 'hammerjs';
import { BranchesComponentComponent } from './branches-component/branches-component.component';
import { BranchesListComponentComponent } from './branches-component/branches-list-component/branches-list-component.component';
import { BranchComponentComponent } from './branches-component/branch-component/branch-component.component';
import { HeaderComponent } from './header/header.component';
import { branchService } from './branches-component/branch.service';

@NgModule({
  declarations: [
    AppComponent,
    ClientsComponentComponent,
    ClientsListComponentComponent,
    ClientComponentComponent,
    BranchesComponentComponent,
    BranchesListComponentComponent,
    BranchComponentComponent,
    HeaderComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatMenuModule,
    MatIconModule,
    NgbModule,
    HttpClientModule,
    FormsModule,
    ConfirmationPopoverModule.forRoot(),    
    BrowserModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatToolbarModule
  ],
  exports:[
  ],
  providers: [ClientService,branchService],
  bootstrap: [AppComponent]
})
export class AppModule { }
