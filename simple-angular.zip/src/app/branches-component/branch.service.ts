import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { branch } from './branch.model';


@Injectable()
export class branchService{
    public branchs : branch[];
    public branch:branch;
constructor(private http:HttpClient){}

getbranchs(){
    //let branchs : any;
    return this.http.get('https://localhost:44362/api/branch');
}
savebranch(branch:branch){
    this.branchs.push(branch);
   return this.http.post('https://localhost:44362/api/branch',branch);
}
deletebranch(branchId){
    let httpParams = new HttpParams().set('id', branchId);
    let options = { params: httpParams };
    return this.http.delete('https://localhost:44362/api/branch/',options);
}
updatebranch(branch:branch){
    for (var i in this.branchs) {
        if (this.branchs[i].branchId == branch.branchId) {
            this.branchs[i].branchName = branch.branchName;
            this.branchs[i].location = branch.location;
            this.branchs[i].managerName = branch.managerName;
            this.branchs[i].budget = branch.budget;
           break; //Stop this loop, we found it!
        }
      }
    return this.http.put('https://localhost:44362/api/branch',branch);
}

onselect(branch:branch){
    this.branch = branch;
}

onsearch(_branch:branch){
    if(Object.entries(_branch).length === 0 && _branch.constructor === branch)
    {
        return this.branchs;
    }
    else{
        var filteredbranchs
        = this.branchs.filter(
            (x)=>{ 
            return (!_branch.branchId || x.branchId == _branch.branchId)&&
            (!_branch.branchName || x.branchName.toLowerCase().indexOf(_branch.branchName.toLowerCase()) !== -1) &&
            (!_branch.location || x.location.toLowerCase().indexOf(_branch.location.toLowerCase()) !== -1) &&
            (!_branch.managerName || x.managerName.toLowerCase().indexOf(_branch.managerName.toLowerCase()) !== -1) &&
            (!_branch.budget || x.budget == _branch.budget)
        });
        return filteredbranchs.slice();
    }
}

}