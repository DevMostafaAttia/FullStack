import { Component, OnInit,EventEmitter,Input,Output } from '@angular/core';
import { branchService } from '../branch.service';
import { branch } from '../branch.model';

@Component({
  selector: 'app-branch-component',
  templateUrl: './branch-component.component.html',
  styleUrls: ['./branch-component.component.css']
})
export class BranchComponentComponent implements OnInit {
  @Input() branch:branch;
  @Output() onsearch = new EventEmitter();
  constructor(private branchService:branchService) { }

  ngOnInit() {
    this.branch = new branch();
    this.branchService.branch = this.branch;
  }

  savebranch(){
    console.log(this.branch);
    if(this.branch.branchId){
      this.branchService.updatebranch(this.branch).subscribe(res=>this.branch = new branch());
    }else{
      this.branchService.savebranch(this.branch).subscribe(res => this.branch = new branch());
    }
  
}

searchbranchs(){
  var branchs = this.branchService.onsearch(this.branch);
  this.onsearch.emit(branchs);
}

cancelAction(){
  this.branch = new branch();
  this.branchService.branch = this.branch;    
}
}
