import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BranchComponentComponent } from './branch-component.component';

describe('BranchComponentComponent', () => {
  let component: BranchComponentComponent;
  let fixture: ComponentFixture<BranchComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BranchComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BranchComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
