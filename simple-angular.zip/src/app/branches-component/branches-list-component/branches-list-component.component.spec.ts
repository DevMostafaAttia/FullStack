import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BranchesListComponentComponent } from './branches-list-component.component';

describe('BranchesListComponentComponent', () => {
  let component: BranchesListComponentComponent;
  let fixture: ComponentFixture<BranchesListComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BranchesListComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BranchesListComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
