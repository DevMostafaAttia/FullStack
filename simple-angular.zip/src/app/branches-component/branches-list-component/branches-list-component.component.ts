import { Component, OnInit , Output, EventEmitter, Input} from '@angular/core';
import { branchService } from '../branch.service';
import { branch } from '../branch.model';
import {Sort} from '@angular/material/sort';

@Component({
  selector: 'app-branches-list-component',
  templateUrl: './branches-list-component.component.html',
  styleUrls: ['./branches-list-component.component.css']
})
export class BranchesListComponentComponent implements OnInit {

  public branchs : branch[];
@Input() public sortedData: branch[];
@Output() onselectbranch = new EventEmitter();

/* Confrimation Pop Up */
public popoverTitle: string = 'Delete branch';
public popoverMessage: string = 'Are you sure deleting this branch !?';
public confirmClicked: boolean = false;
public cancelClicked: boolean = false;

/* Pagination */
public pageSize = 5;
public currentPage = 0;
public totalSize = 0;


  constructor(private branchservice :branchService) { 
    if(this.branchs)this.sortedData = this.branchs.slice();
    
  }

  ngOnInit() {
      //Get branchs from DB 
      this.branchservice.getbranchs().    
      subscribe((response)=>{
        this.branchs =response as branch[];
        this.sortedData = this.branchs.slice();
        this.branchservice.branchs = this.sortedData;
        this.iterator();
      });
  }

  //delete branch by Id
  Deletebranch(branchId){
    console.log(branchId);
    this.sortedData = this.branchs.filter(x=>x.branchId != branchId);
    this.branchservice.deletebranch(branchId).subscribe(res=>console.log('deleted !'));
  }

  //Select branch for edit
  Selectbranch(branch:branch){
    //this.branchservice.branch = branch;
    this.branchservice.onselect(branch);
    this.onselectbranch.emit(branch);
    console.log(branch);
  }

  //Table Sorting
  sortData(sort: Sort) {
    const data = this.branchs.slice();
    if (!sort.active || sort.direction === '') {
      this.sortedData = data;
      return;
    }

    this.sortedData = data.sort((a, b) => {
      const isAsc = sort.direction === 'asc';
      switch (sort.active) {
        case 'branchName': return compare(a.branchName, b.branchName, isAsc);
        case 'location': return compare(a.location, b.location, isAsc);
        case 'managerName': return compare(a.managerName, b.managerName, isAsc);
        case 'budget': return compare(a.budget, b.budget, isAsc);
        default: return 0;
      }
    });

    function compare(a: number | string, b: number | string, isAsc: boolean) {
      return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
    }
  } 
  
//Table Pagination
public handlePage(e: any) {
  this.currentPage = e.pageIndex;
  this.pageSize = e.pageSize;
  this.iterator();
}
private iterator() {
  const end = (this.currentPage + 1) * this.pageSize;
  const start = this.currentPage * this.pageSize;
  const part = this.branchs.slice(start, end);
  this.sortedData = part;
}
  
}
