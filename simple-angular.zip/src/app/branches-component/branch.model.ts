export class branch{
    public branchId :number;
    public branchName:string;
    public location:string;
    public managerName:string;
    public budget:string;
}