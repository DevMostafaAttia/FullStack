import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BranchesComponentComponent } from './branches-component.component';

describe('BranchesComponentComponent', () => {
  let component: BranchesComponentComponent;
  let fixture: ComponentFixture<BranchesComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BranchesComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BranchesComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
