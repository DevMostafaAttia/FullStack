import { Component, OnInit } from '@angular/core';
import { branch } from './branch.model';

@Component({
  selector: 'app-branches-component',
  templateUrl: './branches-component.component.html',
  styleUrls: ['./branches-component.component.css']
})
export class BranchesComponentComponent implements OnInit {
  branch:branch;
  branchs:branch[];

  constructor() { }

  ngOnInit() {
  }

  Showbranch(branch){
    this.branch = branch;
  }

  Searchbranch(branchs){
    this.branchs = branchs;
  }
}
