import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ClientService } from '../client.service';
import { client } from '../client.model';

@Component({
  selector: 'app-client-component',
  templateUrl: './client-component.component.html',
  styleUrls: ['./client-component.component.css']
})
export class ClientComponentComponent implements OnInit {
  @Input() client:client;
  @Output() onsearch = new EventEmitter();
  constructor(private clientService:ClientService) { }

  ngOnInit() {
    this.client = new client();
    this.clientService.client = this.client;
  }

  saveClient(){
      console.log(this.client);
      if(this.client.clientId){
        this.clientService.updateClient(this.client).subscribe(res=>this.client = new client());
      }else{
        this.clientService.saveClient(this.client).subscribe(res => this.client = new client());
      }
    
  }

  searchClients(){
    var clients = this.clientService.onsearch(this.client);
    this.onsearch.emit(clients);
  }

  cancelAction(){
    this.client = new client();
    this.clientService.client = this.client;    
  }
}
