export class client{
    public clientId : number;
    public clientName : string;
    public clientEmail : string;
    public mobile : string;
    public address : string;
    public webSite : string;
}