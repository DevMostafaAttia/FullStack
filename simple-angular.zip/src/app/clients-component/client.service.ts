import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { client } from './client.model';


@Injectable()
export class ClientService{
    public clients : client[];
    public client:client;
constructor(private http:HttpClient){}

getClients(){
    //let clients : any;
    return this.http.get('https://localhost:44362/api/main');
}
saveClient(client:client){
    this.clients.push(client);
   return this.http.post('https://localhost:44362/api/main',client);
}
deleteClient(clientId){
    let httpParams = new HttpParams().set('id', clientId);
    let options = { params: httpParams };
    return this.http.delete('https://localhost:44362/api/main/',options);
}
updateClient(client:client){
    for (var i in this.clients) {
        if (this.clients[i].clientId == client.clientId) {
            this.clients[i].clientName = client.clientName;
            this.clients[i].clientEmail = client.clientEmail;
            this.clients[i].mobile = client.mobile;
            this.clients[i].address = client.address;
            this.clients[i].webSite = client.webSite;
           break; //Stop this loop, we found it!
        }
      }
    return this.http.put('https://localhost:44362/api/main',client);
}

onselect(client:client){
    this.client = client;
}

onsearch(_client:client){
    if(Object.entries(_client).length === 0 && _client.constructor === client)
    {
        return this.clients;
    }
    else{
        var filteredClients
        = this.clients.filter(
            (x)=>{ 
            return (!_client.clientId || x.clientId == _client.clientId)&&
            (!_client.clientName || x.clientName.toLowerCase().indexOf(_client.clientName.toLowerCase()) !== -1) &&
            (!_client.clientEmail || x.clientEmail.toLowerCase().indexOf(_client.clientEmail.toLowerCase()) !== -1) &&
            (!_client.mobile || x.mobile.toLowerCase().indexOf(_client.mobile.toLowerCase()) !== -1) &&
            (!_client.address || x.address.toLowerCase().indexOf(_client.address.toLowerCase()) !== -1)&&
            (!_client.webSite || x.webSite.toLowerCase().indexOf(_client.webSite.toLowerCase()) !== -1)
        });
        return filteredClients.slice();
    }
}

}