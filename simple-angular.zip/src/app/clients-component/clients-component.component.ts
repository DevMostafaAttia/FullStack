import { Component, OnInit } from '@angular/core';
import { client } from './client.model';

@Component({
  selector: 'app-clients-component',
  templateUrl: './clients-component.component.html',
  styleUrls: ['./clients-component.component.css']
})
export class ClientsComponentComponent implements OnInit {
client:client;
clients:client[];
  constructor() { }

  ngOnInit() {
  }

  ShowClient(client){
    this.client = client;
  }

  SearchClient(clients){
    this.clients = clients;
  }
}
