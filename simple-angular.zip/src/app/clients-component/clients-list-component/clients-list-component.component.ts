import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { ClientService } from '../client.service';
import { client } from '../client.model';
import {Sort} from '@angular/material/sort';

@Component({
  selector: 'app-clients-list-component',
  templateUrl: './clients-list-component.component.html',
  styleUrls: ['./clients-list-component.component.css']
})

export class ClientsListComponentComponent implements OnInit {
public clients : client[];
@Input() public sortedData: client[];
@Output() onselectClient = new EventEmitter();

/* Confrimation Pop Up */
public popoverTitle: string = 'Delete Client';
public popoverMessage: string = 'Are you sure deleting this client !?';
public confirmClicked: boolean = false;
public cancelClicked: boolean = false;

/* Pagination */
public pageSize = 5;
public currentPage = 0;
public totalSize = 0;


  constructor(private clientservice :ClientService) { 
    if(this.clients)this.sortedData = this.clients.slice();
    
  }
  
  ngOnInit() {
    //Get Clients from DB 
    this.clientservice.getClients().    
    subscribe((response)=>{
      this.clients =response as client[];
      this.sortedData = this.clients.slice();
      this.clientservice.clients = this.sortedData;
      this.iterator();
    });
  }

  //delete client by Id
  DeleteClient(clientId){
    console.log(clientId);
    this.sortedData = this.clients.filter(x=>x.clientId != clientId);
    this.clientservice.deleteClient(clientId).subscribe(res=>console.log('deleted !'));
  }

  //Select Client for edit
  SelectClient(client:client){
    //this.clientservice.client = client;
    this.clientservice.onselect(client);
    this.onselectClient.emit(client);
    console.log(client);
  }

  //Table Sorting
  sortData(sort: Sort) {
    const data = this.clients.slice();
    if (!sort.active || sort.direction === '') {
      this.sortedData = data;
      return;
    }

    this.sortedData = data.sort((a, b) => {
      const isAsc = sort.direction === 'asc';
      switch (sort.active) {
        case 'clientName': return compare(a.clientName, b.clientName, isAsc);
        case 'clientEmail': return compare(a.clientEmail, b.clientEmail, isAsc);
        case 'mobile': return compare(a.mobile, b.mobile, isAsc);
        case 'address': return compare(a.address, b.address, isAsc);
        case 'protein': return compare(a.webSite, b.webSite, isAsc);
        default: return 0;
      }
    });

    function compare(a: number | string, b: number | string, isAsc: boolean) {
      return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
    }
  } 
  
//Table Pagination
public handlePage(e: any) {
  this.currentPage = e.pageIndex;
  this.pageSize = e.pageSize;
  this.iterator();
}
private iterator() {
  const end = (this.currentPage + 1) * this.pageSize;
  const start = this.currentPage * this.pageSize;
  const part = this.clients.slice(start, end);
  this.sortedData = part;
}
  
}
