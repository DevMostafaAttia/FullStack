import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ClientsComponentComponent } from './clients-component/clients-component.component';
import { BranchesComponentComponent } from './branches-component/branches-component.component';


const routes: Routes = [ 
  { path: '', redirectTo: '/clients', pathMatch: 'full' },
  { path: 'clients', component : ClientsComponentComponent },
  { path: 'branches', component : BranchesComponentComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
